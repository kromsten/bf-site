import{default as t}from"../components/error.svelte-dc71cc27.js";export{t as component};
