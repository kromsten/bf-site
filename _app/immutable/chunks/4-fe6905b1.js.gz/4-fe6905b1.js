import{default as t}from"../components/pages/what/_page.svelte-d0081688.js";export{t as component};
