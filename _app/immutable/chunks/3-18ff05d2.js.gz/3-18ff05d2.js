import{default as t}from"../components/pages/faq/_page.svelte-d85b149a.js";export{t as component};
