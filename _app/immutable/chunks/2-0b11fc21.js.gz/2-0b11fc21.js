import{default as t}from"../components/pages/_page.svelte-210f902c.js";export{t as component};
